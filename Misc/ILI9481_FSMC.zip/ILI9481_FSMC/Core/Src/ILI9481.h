#ifndef ILI9481_H_
#define ILI9481_H_ 

#include "stm32f2xx_hal.h"  

#define ADDR_CMD    *(uint16_t *) 0X60000000 
#define ADDR_DATA   *(uint16_t *) 0x60080000  ///  0x0001fffE   ///  0X60080000

#define swap(a,b) {int16_t t=a;a=b;b=t;}

#define  RESET_ACTIVE   HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET); 
#define  RESET_IDLE     HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_SET); 
 
#define  BLACK   0x0000
#define  BLUE    0x001F
#define  RED     0xF800
#define  GREEN   0x07E0
#define  CYAN    0x07FF
#define  MAGENTA 0xF81F
#define  YELLOW  0xFFE0
#define  WHITE   0xFFFF

//------------------------------------------------
#define convert24to16(x) (((x & 0x00F80000)>>8)|((x & 0x0000FC00)>>5)|((x & 0x000000F8)>>3))
//------------------------------------------------
void ili9481_ini(void);
void ili9481_SetRotation(uint8_t r);
void ili9481_FillScreen(uint16_t color);
uint16_t ili9481_RandColor(void);
void ili9481_FillRect(uint16_t color, uint16_t x1, uint16_t y1,
											uint16_t x2, uint16_t y2);
void ili9481_DrawPixel(int x1, int y1, uint16_t color);
void ili9481_DrawLine(uint16_t color, uint16_t x1, uint16_t y1,
											uint16_t x2, uint16_t y2);
void ili9481_DrawRect(uint16_t color, uint16_t x1, uint16_t y1,
											uint16_t x2, uint16_t y2);
void ili9481_DrawCircle(uint16_t x0, uint16_t y0, int r, uint16_t color);
void ili9481_DrawChar(uint16_t x, uint16_t y, uint8_t s);
void ili9481_SetFont(uint8_t f);
void ili9481_SetTextColor(uint16_t color);
void ili9481_SetBackColor(uint16_t color);
void ili9481_String(uint16_t x,uint16_t y, char *str);
void ili9481_DrawBitmap(uint16_t x,uint16_t y, char *s);
void TFT_FillColor(const uint16_t color);
//------------------------------------------------
#endif /* ILI9481_H_ */

