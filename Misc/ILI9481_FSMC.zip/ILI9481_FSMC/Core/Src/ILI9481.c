
#include "stm32f2xx_hal.h" 
#include "ILI9481.h" 
 #include "string.h"
 #include "stdio.h "
 
 extern UART_HandleTypeDef huart4;
 
// ============================================
uint16_t X_SIZE = 0; 
uint16_t Y_SIZE = 0;
uint32_t dtt=0;
uint32_t id; 
extern char str[10];
// ================================================
void ili9481_SendCommand(unsigned char cmd) 
{ 
        ADDR_CMD = cmd; 
}
// ================================================ 
void ili9481_SendData(unsigned char dt) 
{ 
        ADDR_DATA = dt;  
}  
// ==================================================================
uint32_t ili9481_ReadReg(uint8_t r) 
{ 
        
        uint8_t x; 
        ili9481_SendCommand(r); 
        HAL_Delay(5);                 /////////////////////////////////////////////////////////////////////////////
        x=ADDR_DATA; 
        id=x; 
        id<<=8; 
        HAL_Delay(1); 
        x=ADDR_DATA; 
        id|=x; 
        id<<=8; 
        HAL_Delay(1); 
        x=ADDR_DATA; 
        id|=x; 
        id<<=8; 
        HAL_Delay(1); 
        x=ADDR_DATA; 
        id|=x; 
	id<<=8; 
	      HAL_Delay(1); 
        x=ADDR_DATA; 
        id|=x;
				id<<=8; 
				HAL_Delay(1); 
        x=ADDR_DATA; 
        id|=x;
	      
        if(r==0xEF) 
        { 
                id<<=8; 
                HAL_Delay(5); 
                x=ADDR_DATA; 
                id|=x; 
        } 
        HAL_Delay(150);//stabilization time 
        return id; 
}
// ===============================================================
void ili9481_SetRotation(unsigned char r) // ??????????????????????????????????????????????????????????????????????????
{ 
        ili9481_SendCommand(0x36); 
        switch(r) 
        { 
                case 0: 
                ili9481_SendData(0x00|0x02);  // (0x48); 
                X_SIZE = 320; 
                Y_SIZE = 480; 
                break; 
                case 1: 
                ili9481_SendData(0x28);    //  (0x28); 
                X_SIZE = 480; 
                Y_SIZE = 320; 
                break; 
                case 2: 
                ili9481_SendData(0x88);   //  (0x88); 
                X_SIZE = 320; 
                Y_SIZE = 480; 
                break; 
                case 3: 
                ili9481_SendData(0xE8);   //  (0xE8);  
                X_SIZE = 480; 
                Y_SIZE = 320; 
                break; 
        } 
} 
// ======================================================= 
void ini_ili9481 (void)
{ 
	
	
	 ili9481_ReadReg(0xBF);
	
    RESET_IDLE;
    HAL_Delay(5);
    RESET_ACTIVE;
    HAL_Delay(20);
    RESET_IDLE;
    HAL_Delay(150);  
	  ili9481_SendCommand(0x01);
  	HAL_Delay(20); 
    ili9481_SendCommand(0x11);
    HAL_Delay(20);
	
	  
 
	//  ================= ###########################################################
	
	/////////////////////////////  ILI9481     ///////////////////////////////////
	 
	 ili9481_SendCommand(0xD0);
  ili9481_SendData(0x07);
  ili9481_SendData(0x42);
  ili9481_SendData(0x18);

  ili9481_SendCommand(0xD1);
  ili9481_SendData(0x00);
  ili9481_SendData(0x07);
  ili9481_SendData(0x10);

  ili9481_SendCommand(0xD2);
  ili9481_SendData(0x01);
  ili9481_SendData(0x02);

  ili9481_SendCommand(0xC0);
  ili9481_SendData(0x10);
  ili9481_SendData(0x3B);
  ili9481_SendData(0x00);
  ili9481_SendData(0x02);
  ili9481_SendData(0x11);

  ili9481_SendCommand(0xC5);
  ili9481_SendData(0x03);

  ili9481_SendCommand(0xC8);
  ili9481_SendData(0x00);
  ili9481_SendData(0x32);
  ili9481_SendData(0x36);
  ili9481_SendData(0x45);
  ili9481_SendData(0x06);
  ili9481_SendData(0x16);
  ili9481_SendData(0x37);
  ili9481_SendData(0x75);
  ili9481_SendData(0x77);
  ili9481_SendData(0x54);
  ili9481_SendData(0x0C);
  ili9481_SendData(0x00);

  ili9481_SendCommand(0x36);
  ili9481_SendData(0x02);  //  a(0x02)

  ili9481_SendCommand(0x3A);
  ili9481_SendData(0x55);
	 
                                  //   ili9481_SendCommand(0x21);
		  

  ili9481_SendCommand(0x2A);
  ili9481_SendData(0x00);
  ili9481_SendData(0x00);
  ili9481_SendData(0x01);
  ili9481_SendData(0x3F);

  ili9481_SendCommand(0x2B);
  ili9481_SendData(0x00);
  ili9481_SendData(0x00);
  ili9481_SendData(0x01);
  ili9481_SendData(0xDF);
	
	
//  ===================############################################## 
    HAL_Delay(120);
    ili9481_SendCommand(0x29); 
		HAL_Delay(20);
}
// ===============================================================
void ili9481_Flood(uint16_t color, uint32_t len) 
{ 
         uint16_t blocks; 
         uint8_t i, hi = color>>8, lo=color & 0xFF ; 
        //  ili9481_SendCommand(0x2C);  
        ili9481_SendData(hi);   
	      ili9481_SendData(lo); 
        len--; 
        blocks=(uint16_t)(len/64);//64 pixels/block 
        while(blocks--) 
        { 
                i=16; 
                do 
                { 
                        ili9481_SendData(hi); 
                        ili9481_SendData(lo); 
                        ili9481_SendData(hi); 
                        ili9481_SendData(lo); 
                        ili9481_SendData(hi); 
                        ili9481_SendData(lo); 
                        ili9481_SendData(hi); 
                        ili9481_SendData(lo); 
                } while (--i); 
        } 
        //Fill any remaining pixels(1 to 64) 
        for (i=(uint8_t)len&63;i--;) 
        { 
                ili9481_SendData(hi); 
                ili9481_SendData(lo); 
        } 

//      uint8_t   hi = color>>8, lo=color   ;
//      for (len = 0; len < 153600; len++)
//        {
//            ili9481_SendData(hi);
//					  ili9481_SendData(lo);
//        }  

} 
//��������������������� 


void ili9481_SetAddrWindow(uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2) 
{ 
  ili9481_SendCommand(0x2A);//Column Addres Set 
  ili9481_SendData(x1 >> 8); 
  ili9481_SendData(x1 & 0xFF); 
  ili9481_SendData(x2 >> 8); 
  ili9481_SendData(x2 & 0xFF);  
  ili9481_SendCommand(0x2B);//Page Addres Set 
  ili9481_SendData(y1 >> 8); 
  ili9481_SendData(y1 & 0xFF); 
  ili9481_SendData(y2 >> 8); 
  ili9481_SendData(y2 & 0xFF); 
	ili9481_SendCommand(0x2C); 
} 
//��������������������� 


//============================================================
void ili9481_DrawPixel(int x, int y, uint16_t color)
{
	if((x<0)||(y<0)||(x>=X_SIZE)||(y>=Y_SIZE)) return;
	ili9481_SetAddrWindow(x,y,x,y);
	 ili9481_SendCommand(0x2C);
	ili9481_SendData(color>>8);
	ili9481_SendData(color & 0xFF);
}

// ========================================================
void ili9481_FillScreen(uint16_t color) 
{ 
        ili9481_SetAddrWindow(0,0,X_SIZE-1,Y_SIZE-1); 
        ili9481_Flood(color,(long)X_SIZE*(long)Y_SIZE);
} 
//���������������������

void ili9481_FillRect(uint16_t color, uint16_t x1, uint16_t y1,
											uint16_t x2, uint16_t y2)
{
	ili9481_SetAddrWindow(x1,y1,x2,y2);
	ili9481_Flood(color,(uint16_t)(x2-x1+1)*(uint16_t)(y2-y1+1));
}
//  =======================
void TFT_FillColor(const uint16_t color)
{
	ili9481_SetAddrWindow(0, 0, 319, 479);
	for (int x = 0; x <= 319; x++)
    {
     //  taskYIELD();
       for (int y = 0; y <= 479; y++)
       {
          ili9481_SendData (color);
       }
    }
}


