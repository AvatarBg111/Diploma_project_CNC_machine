/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

   
   #include "ili9481_fsmc.h" 
	 #include "Img.h"
	 #include "lob_vybor.h"   
	 #include "lob_ok.h"
	 #include "lob_net.h"   
	 #include "lobnogi_vybor.h"
	 #include "lobnogi_ok.h"
	 #include "lobnogi_net.h"
	 #include "nogi_vybor.h"
	 #include "nogi_ok.h"
	 #include "nogi_net.h"
	 #include "nogirylo_vybor.h"
	 #include "nogirylo_ok.h"
	 #include "nogirylo_net.h"
	 #include "rylo_vybor.h"
	 #include "rylo_ok.h"
	 #include "rylo_net.h"
   #include "logo.h"
	 #include "polzun.h"
	 #include "grel.h"
   #include "avto.h"
   #include "ventil.h"
	 #include "ustan.h" 
   #include "argon.h"
	 #include "negrel.h" 
	 #include "ruchnoe.h"
	 #include "ustpolzun.h"
 
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

		#define led1    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_11, GPIO_PIN_SET)
    #define led0    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_11, GPIO_PIN_RESET) 
		
    #define blk1    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_SET)
    #define blk0    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET) 
		
		#define but0    HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_8)==GPIO_PIN_RESET
    #define but1    HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_8)==GPIO_PIN_SET
		
		#define leds    HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_11)
 
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
 
						
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim8;

SRAM_HandleTypeDef hsram1;

/* USER CODE BEGIN PV */

uint8_t rejim_vybora,  encvyb, raz, buffpolzun,buffpolzun1, buffpolzun2,buffpolzun3;
uint8_t enc, buffenc, membuffenc, raz_ust, ust,buff_ust, mem_ust,ust_enc;
uint8_t raz_vyb, mem_vyb, buff_vyb, ust_vyb;
 
uint16_t b ,tik, ojid,ust_tik, tik_vyb, ruch_tik, polojenie_polzun, buff_polzun, ust_polzun ;
uint8_t ruch, avtoma,dwoj, ustan_avto, ruch_raz ;

uint8_t xBuffer[1]; 
#define I2C1_DEVICE_ADDRESS      0x50   /* A0 = A1 = A2 = 0 */ 
uint8_t MEMORY_ADDRESS ; 
 
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_FSMC_Init(void);
static void MX_TIM8_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */
 extern void ili9481_ini(void);    
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */ 

// ========================  vybor   ================================													 
	void vybor ()
	{
		
					 	  Draw_Image(lob_net,       384,   0, 96/* width */, 66/* height */, 6336);   
					    Draw_Image(lobnogi_net,   288,   0, 96/* width */, 66/* height */, 6336);   
					    Draw_Image(nogi_net,      192,   0, 96/* width */, 66/* height */, 6336);   
						 	Draw_Image(nogirylo_net,   96,   0, 96/* width */, 66/* height */, 6336);  
					  	Draw_Image(rylo_net,      0,   0, 96/* width */, 66/* height */, 6336);  		
		
		 switch (ust_vyb)    
			{
			case 0:
			{   
					  	Draw_Image(rylo_vybor,      0,   0, 96/* width */, 66/* height */, 6336);   
			} 
				break;
			case 1:
			{    
				 		Draw_Image(nogirylo_vybor,   96,   0, 96/* width */, 66/* height */, 6336);    
			} 
				break;
			case 2:
			{  
				  	Draw_Image(nogi_vybor,       192,   0, 96/* width */, 66/* height */, 6336);    
			}
				break;
			case 3:
			{   
			    	Draw_Image(lobnogi_vybor,    288,   0, 96/* width */, 66/* height */, 6336);   
			}
				break;
			case 4:
			{
					Draw_Image(lob_vybor,           384,   0, 96/* width */, 66/* height */, 6336);   
			}
				break;
			default: 
				break;
			}  
	}		
	
	
		void vybor_ok ()
	{
		
					 	  Draw_Image(lob_net,       384,   0, 96/* width */, 66/* height */, 6336);   
					    Draw_Image(lobnogi_net,   288,   0, 96/* width */, 66/* height */, 6336);   
					    Draw_Image(nogi_net,      192,   0, 96/* width */, 66/* height */, 6336);   
						 	Draw_Image(nogirylo_net,   96,   0, 96/* width */, 66/* height */, 6336);  
					  	Draw_Image(rylo_net,      0,   0, 96/* width */, 66/* height */, 6336); 
		
		 switch (ust_vyb)    
			{
			case 0:
			{   
					  	Draw_Image(rylo_ok,      0,   0, 96/* width */, 66/* height */, 6336);   
			} 
				break;
			case 1:
			{    
				 		Draw_Image(nogirylo_ok,   96,   0, 96/* width */, 66/* height */, 6336);    
			} 
				break;
			case 2:
			{  
				  	Draw_Image(nogi_ok,       192,   0, 96/* width */, 66/* height */, 6336);    
			}
				break;
			case 3:
			{  
			    	Draw_Image(lobnogi_ok,    288,   0, 96/* width */, 66/* height */, 6336);    
			}
				break;
			case 4:
			{
					Draw_Image(lob_ok,           384,   0, 96/* width */, 66/* height */, 6336);    
			}
				break;
			default: 
				break;
			}  
	}		
	
	
	//  ============  write eeprom ===========================
	
	void write_eep (uint8_t wrem)  
	{
		  
		if(buffenc==0||buffenc!=0) 
				{
					 MEMORY_ADDRESS=0x00,xBuffer[0] = buffenc ; 
					 HAL_I2C_Mem_Write(&hi2c1, (uint16_t) I2C1_DEVICE_ADDRESS<<1, MEMORY_ADDRESS, 1, xBuffer, 1, 5);   
					 HAL_Delay(10);  
				}
				
 		if(buff_ust==0||buff_ust!=0) MEMORY_ADDRESS=0x01, xBuffer[0] = buff_ust;
 		HAL_I2C_Mem_Write(&hi2c1, (uint16_t) I2C1_DEVICE_ADDRESS<<1, MEMORY_ADDRESS, 1, xBuffer, 1, 5);   
        		HAL_Delay(10);
		
		if(buff_vyb==0||buff_ust!=0) MEMORY_ADDRESS=0x02, xBuffer[0] = buff_vyb;
		HAL_I2C_Mem_Write(&hi2c1, (uint16_t) I2C1_DEVICE_ADDRESS<<1, MEMORY_ADDRESS, 1, xBuffer, 1, 5);   
       		HAL_Delay(10);
		
		if(buff_polzun==0||buff_polzun!=0) MEMORY_ADDRESS=0x03, xBuffer[0] = buff_polzun;
		HAL_I2C_Mem_Write(&hi2c1, (uint16_t) I2C1_DEVICE_ADDRESS<<1, MEMORY_ADDRESS, 1, xBuffer, 1, 5);   
       		HAL_Delay(10);		

		if(avtoma==0||avtoma!=0) MEMORY_ADDRESS=0x04, xBuffer[0] = avtoma;
		HAL_I2C_Mem_Write(&hi2c1, (uint16_t) I2C1_DEVICE_ADDRESS<<1, MEMORY_ADDRESS, 1, xBuffer, 1, 5);   
       		HAL_Delay(10);	

                     for(uint8_t i=0;i<6;i++)
												 {
													 led1;
													 HAL_Delay(10);
													 led0;
													 HAL_Delay(70);
												 } 				
     
	}		 
	// ===========  end read eeprom ==============================
	
	void  read_eep (uint8_t wrem)
	{
		if(membuffenc==0||membuffenc!=0)  
		{		
			  MEMORY_ADDRESS=0x00;		
				HAL_I2C_Mem_Read(&hi2c1, (uint16_t) I2C1_DEVICE_ADDRESS<<1, MEMORY_ADDRESS, 1, xBuffer, 1, 5); 
				membuffenc=xBuffer[0] ;	  
		}
		
 		if(mem_ust==0||mem_ust!=0)  MEMORY_ADDRESS=0x01;		
 		HAL_I2C_Mem_Read(&hi2c1, (uint16_t) I2C1_DEVICE_ADDRESS<<1, MEMORY_ADDRESS, 1, xBuffer, 1, 5); 
    mem_ust=xBuffer[0] ;		
	
		if(mem_vyb==0||mem_vyb!=0)  MEMORY_ADDRESS=0x02;		
		HAL_I2C_Mem_Read(&hi2c1, (uint16_t) I2C1_DEVICE_ADDRESS<<1, MEMORY_ADDRESS, 1, xBuffer, 1, 5); 
    mem_vyb=xBuffer[0] ;
		
		if(buff_polzun==0||buff_polzun!=0)  MEMORY_ADDRESS=0x03;		
		HAL_I2C_Mem_Read(&hi2c1, (uint16_t) I2C1_DEVICE_ADDRESS<<1, MEMORY_ADDRESS, 1, xBuffer, 1, 5); 
    buff_polzun=xBuffer[0] ;
		
	  if(avtoma==0||avtoma!=0)  MEMORY_ADDRESS=0x04;		
		HAL_I2C_Mem_Read(&hi2c1, (uint16_t) I2C1_DEVICE_ADDRESS<<1, MEMORY_ADDRESS, 1, xBuffer, 1, 5); 
    avtoma=xBuffer[0] ;
		 
	}
	 
		void vstup ()  
	{
//	  Draw_Image(img,   0,   0, 480/* width */, 320/* height */, 153600);
// 		Draw_Image(logo,  113,    31, 255/* width */, 183/* height */, 46665);
// 		Draw_Image(argon,  53,    255, 375/* width */, 60/* height */, 22500);
//	  HAL_Delay(1500);
	}
	
	void shkurka () 
	{
		  if(avtoma==0)
			{ 
					Draw_Image(avto,   10,  78, 467/* width */, 50/* height */, 23350); 
					ili9481_FillRect(BLACK, 335, 78,475, 128);
					ili9481_FillRect(BLACK, 335, 190,475, 240); 
					Draw_Image(negrel,   0,   141, 480/* width */, 40/* height */, 19200); 
				vybor_ok ();
				num_48(340 ,80 ,YELLOW,BLACK,ust_enc,2);
				ventil(enc) ; 
			}
			
		if(avtoma==1)
			{ 
					Draw_Image(ruchnoe,   10,  78, 467/* width */, 50/* height */, 23350); 
					ili9481_FillRect(BLACK, 335, 190,475, 240); 
					Draw_Image(grel,   0,   141, 480/* width */, 40/* height */, 19200);  
				ventil(enc) ; 
				Draw_Image(polzun,   polojenie_polzun,   141, 49/* width */, 40/* height */, 1960);
				vybor_ok (); 
				 
			}
	}
													 
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
           
	
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_FSMC_Init();
  MX_TIM8_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */
  
	// =======================================================
	 HAL_TIM_Encoder_Start(&htim8, TIM_CHANNEL_1); 
	 // ======================================================
	
		Init_Disp();	 
		blk1;  

    vstup () ;
		Draw_Image(img,   0,   0, 480/* width */, 320/* height */, 153600); 
		shkurka ();
		 
		 
		 TIM8->CNT=0;
		  
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */ 
	
	
	
	          read_eep (mem_ust); 
						buff_ust=mem_ust;
						ust_enc=buff_ust;  
						
						read_eep (mem_vyb); 
						buff_vyb=mem_vyb;
						ust_vyb=buff_vyb; 
						
						read_eep (membuffenc); 
						buffenc=membuffenc;    
						enc=buffenc; 
						
						read_eep (buff_polzun);  
						ust_polzun=buff_polzun; 
						
						read_eep (avtoma); 
						
						vybor_ok ();
					  num_48(340 ,80 ,YELLOW,BLACK,ust_enc,2);   

  while (1)
  { 
		
 		num_48(340 ,192 ,YELLOW,BLACK,25,2); // temper salon  
// =====================  rejim_ventiljatora  ========================================
		
		if(rejim_vybora==0 )  //  ventiljator
		{   
			    if(raz==0)
						{   
							TIM8->CNT=buffenc*2 ;    
						//	ventil(enc); 
							shkurka();
							raz=1;   
							raz_ust=0;
							raz_vyb=0; 
						}
			      
    			if(raz==2)
					{  
            tik++; 
						if(tik>=1000) 
						{
							tik=0;
							write_eep (buffenc) ;  
							raz=3;   
							raz_vyb=0;
						}
					}			
          if(TIM8->CNT>=70) TIM8->CNT=70; 			
          buffenc= TIM8->CNT / 2 ; 			 		
					if(enc!=buffenc)enc=buffenc , raz=2,tik=0, ventil(enc) ; 
			} 
// ===================== end  rejim_ventiljatora  ========================================		
  
// ===========================  ruki nogi =================================	 
		 
  if(rejim_vybora==2)
	{ 
    tik_vyb++;
			if(raz_vyb==0)
				{ 
								TIM8->CNT=buff_vyb*2;   
								vybor ();  
					      raz_vyb=1; 
				}
					 if(tik_vyb>=1000)   
						{
							if(raz_vyb==2)
									 {
										 write_eep (buff_vyb) , raz_vyb=3   ;   
										} 
								  tik_vyb=0;
							    raz=0;
								  vybor_ok();
							    rejim_vybora=0 ; 
								  //num_48(340 ,80 ,YELLOW,BLACK,ust_enc,2);
										shkurka();
						}
		       if(TIM8->CNT>=8) TIM8->CNT=8; 	 
		       buff_vyb= TIM8->CNT  / 2; 
					if( ust_vyb != buff_vyb ) ust_vyb = buff_vyb , raz_vyb =2,  tik_vyb =0,vybor () ; //  , ojid=0
	}		
// ===========================  end ruki nogi =================================	   
			
 // ===========================  knopka encoder =================================	
		
//       idi i smotri  :-)))  https://www.drive2.ru/b/465392211907838028/
  
			if(but0&&b<301) b++;  // ,  HAL_Delay(1) 
			if(but1&&b<20) b=0;
			if(but1&&b>=20)  		                       // korotkoe najatie     
				{
					b=0; 
					//tik=0;
					ojid=0;
				  dwoj=1; 
				}
		 
		 	  	if(b>150)                                  // dlinnoe najatie 
					{ 
             rejim_vybora=2;  
						 vybor (); 
							while(but0) { }; 
							b=0; 
					}
// =============  dvojnoe najatie ==================================

	 if(dwoj==1)  
		{		
    		ojid++;	
			 if(ojid<=80) 
			 {
				 if(but0)
				 { 
					 if(avtoma==1) avtoma=0;
					 else          avtoma=1;
					 write_eep (avtoma);
					 shkurka ();
					 dwoj=0;
					 ojid=0; 
					 while(but0){};
				 } 
			 } 
			 if(ojid>=150) 
			 { 
				  if(avtoma==0)rejim_vybora=1; 
				  if(avtoma==1)rejim_vybora=3; 
				 ojid=0;
				 dwoj=0;
			 }
			 
		 }				 
// ===========================  end knopka encoder =================================		 
// ===========================  avtomat =================================
// ===========================  avtomat =================================
// ===========================  avtomat =================================
		 

//// ===========================  end avtomat =================================		

		 if(avtoma==0)
		 {
		 
// ===========================  ustanovka avtomat =================================	
  
    if(rejim_vybora==1)  // ustanovka avtomat
      {   
				ust_tik++; 
				 if(raz_ust==0)
							 { 
										TIM8->CNT=buff_ust*2;   
										Draw_Image(ustan,   10,  88, 291/* width */, 37/* height */, 10767);  
								    raz_ust=1;
							 }		  
				  
										if(ust_tik>=1000)
										{
											if(raz_ust==2) 
													{
															write_eep (buff_ust) , raz_ust=4;  
														  ust_tik=0;
												      raz_ust=3; 
											      	raz=0; 
														  rejim_vybora=0; 
													}
												ust_tik=0;
												raz_ust=3; 
												raz=0;
											  rejim_vybora=0; 
										}		 
									if(TIM8->CNT>=70) TIM8->CNT=70;
									if(TIM8->CNT<=30) TIM8->CNT=30;
									buff_ust= TIM8->CNT  / 2; 
									if( ust_enc != buff_ust ) ust_enc = buff_ust , raz_ust =2, ust_tik =0  ;
						    	num_48(340 ,80 ,0xfb40,BLACK,ust_enc,2);  
  } 
		
 //  =====================   ruchnoe ==============================================           
 					   
  } 

			
	if(avtoma==1)
	{ 
		
				  if(ruch_raz==0)
				 { 
					  TIM8->CNT=buff_polzun*2;
						polojenie_polzun=buff_polzun*43;
						if(buff_polzun==10) polojenie_polzun=431;
						Draw_Image(grel,   0,   141, 480/* width */, 40/* height */, 19200); 
						Draw_Image(polzun,   polojenie_polzun,   141, 49/* width */, 40/* height */, 1960);
						ruch_raz=1;
					  rejim_vybora=0; 
				    raz=0;
				 }
		
     if(rejim_vybora==3)
    	{
				ruch_tik++;
		  if(ruch_raz==1)
				 { 
					  TIM8->CNT=buff_polzun*2;
						polojenie_polzun=buff_polzun*43;
						if(buff_polzun==10) polojenie_polzun=431;
						Draw_Image(grel,   0,   141, 480/* width */, 40/* height */, 19200); 
						Draw_Image(ustpolzun,   polojenie_polzun,   141, 49/* width */, 40/* height */, 1960);
						ruch_raz=2;
				 }
		
		       if(TIM8->CNT>=20) TIM8->CNT=20; 	 
		       buff_polzun= TIM8->CNT  / 2; 
					 if( ust_polzun != buff_polzun ) ust_polzun = buff_polzun, ruch_raz=1 , ruch_tik=0 ;
		 }
			
		 if(ruch_tik>=1000)
		 {
			    write_eep (buff_polzun); 
			    ruch_tik=0;
	        Draw_Image(grel,   0,   141, 480/* width */, 40/* height */, 19200); 
		      Draw_Image(polzun,   polojenie_polzun,   141, 49/* width */, 40/* height */, 1960);
			    rejim_vybora=0;
			    ruch_raz=0;
				  raz=0;
		 }
		 
	}		

	
					
//	  if(rejim_vybora==0)
//	{
//		  tik=0;
//		  Draw_Image(lob_ok,   384,   0, 96/* width */, 66/* height */, 6336);
//  	  Draw_Image(rylo_net,   0,   0, 96/* width */, 66/* height */, 6336); 
//		  Draw_Image(salon,   7,   196, 295/* width */, 49/* height */, 14455);
//		 Draw_Image(grel,   0,   141, 480/* width */, 40/* height */, 19200);
//	}
//					
//		 if(rejim_vybora!=0)
//			{
//				 tik++;
//				 HAL_Delay(1);
//				if(tik>=500) rejim_vybora=0, led0; 
//				Draw_Image(ustan,   7,   196, 295/* width */, 49/* height */, 14455);
//				 Draw_Image(negrel,   0,   141, 480/* width */, 40/* height */, 19200);
//				Draw_Image(ruchnoe,   10,  88, 291/* width */, 36/* height */, 10476);
//				 //vybor ();  
//			}
//			
//			if(rejim_vybora==1)
//			{
//				    buffenc= TIM8->CNT  / 2; 
//	   	      if(enc!=buffenc)enc=buffenc, ventil(enc), tik=0 , raz=0 ;
//				  if(raz==0)
//						{
//							 read_eep (buffpolzun3);
//				  	   num_48(240 ,80 ,YELLOW,BLACK,buffpolzun3,3); 
//						   num_48(340 ,192 ,YELLOW,BLACK,enc,2); 
//							 raz=1;
//					 }
//			}
//   					
// ===================== end rejim_vybora  ========================================					
//   
//     
//		
//		
//		ili9481_FillScreen (GREEN);  //  lobnogi_vybor
//		HAL_Delay(500);  
//	  	ili9481_FillRect(RED, 248, 50,400, 130); 
//		HAL_Delay(500);	
//  	ili9481_FillRect(BLUE, 0, 0,240, 160); 
//		HAL_Delay(500);  
//   	ili9481_FillRect(WHITE, 0, 0,240, 160); 
//	  HAL_Delay(500);
//    ili9481_FillRect(WHITE, 240,  160,400, 300); 
//	 ili9481_FillScreen (BLACK); 
//	HAL_Delay(500);
// ili9481_DrawRect(YELLOW, 50, 50,10, 10);
// HAL_Delay(500);
//	  ili9481_DrawPixel(200, 200, WHITE);
//		HAL_Delay(500);
//	  ili9481_DrawCircle(200, 200, 50, WHITE);
//		HAL_Delay(500);
//		 ili9481_DrawLine(RED, 0, 0,	300, 23);
//	 HAL_Delay(500);
//     ili9481_FillRect(WHITE, 0, 0,240, 160);		
//		HAL_Delay(500);
//		ili9481_FillRect(CYAN, 240, 0,480, 160);
//		HAL_Delay(500);
////	 ili9481_FillScreen (GREEN);
////HAL_Delay(500);	 
//		ili9481_FillRect(YELLOW, 240,  160,480, 320);
//		HAL_Delay(500);
//				ili9481_FillRect(BLUE, 0, 160,240, 320);
//		HAL_Delay(500);
// 
// 
		HAL_Delay(1);
		
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 13;
  RCC_OscInitStruct.PLL.PLLN = 195;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 5;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 50000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM8 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM8_Init(void)
{

  /* USER CODE BEGIN TIM8_Init 0 */

  /* USER CODE END TIM8_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM8_Init 1 */

  /* USER CODE END TIM8_Init 1 */
  htim8.Instance = TIM8;
  htim8.Init.Prescaler = 0;
  htim8.Init.CounterMode = TIM_COUNTERMODE_CENTERALIGNED3;
  htim8.Init.Period = 100;
  htim8.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim8.Init.RepetitionCounter = 0;
  htim8.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI1;
  sConfig.IC1Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 15;
  sConfig.IC2Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 15;
  if (HAL_TIM_Encoder_Init(&htim8, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim8, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM8_Init 2 */

  /* USER CODE END TIM8_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(RESET_GPIO_Port, RESET_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(BLK_GPIO_Port, BLK_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : RESET_Pin */
  GPIO_InitStruct.Pin = RESET_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(RESET_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : BLK_Pin */
  GPIO_InitStruct.Pin = BLK_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(BLK_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : buttenc_Pin */
  GPIO_InitStruct.Pin = buttenc_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(buttenc_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LED_Pin */
  GPIO_InitStruct.Pin = LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);

}

/* FSMC initialization function */
static void MX_FSMC_Init(void)
{

  /* USER CODE BEGIN FSMC_Init 0 */

  /* USER CODE END FSMC_Init 0 */

  FSMC_NORSRAM_TimingTypeDef Timing = {0};

  /* USER CODE BEGIN FSMC_Init 1 */

  /* USER CODE END FSMC_Init 1 */

  /** Perform the SRAM1 memory initialization sequence
  */
  hsram1.Instance = FSMC_NORSRAM_DEVICE;
  hsram1.Extended = FSMC_NORSRAM_EXTENDED_DEVICE;
  /* hsram1.Init */
  hsram1.Init.NSBank = FSMC_NORSRAM_BANK1;
  hsram1.Init.DataAddressMux = FSMC_DATA_ADDRESS_MUX_DISABLE;
  hsram1.Init.MemoryType = FSMC_MEMORY_TYPE_SRAM;
  hsram1.Init.MemoryDataWidth = FSMC_NORSRAM_MEM_BUS_WIDTH_16;
  hsram1.Init.BurstAccessMode = FSMC_BURST_ACCESS_MODE_DISABLE;
  hsram1.Init.WaitSignalPolarity = FSMC_WAIT_SIGNAL_POLARITY_LOW;
  hsram1.Init.WrapMode = FSMC_WRAP_MODE_DISABLE;
  hsram1.Init.WaitSignalActive = FSMC_WAIT_TIMING_BEFORE_WS;
  hsram1.Init.WriteOperation = FSMC_WRITE_OPERATION_ENABLE;
  hsram1.Init.WaitSignal = FSMC_WAIT_SIGNAL_DISABLE;
  hsram1.Init.ExtendedMode = FSMC_EXTENDED_MODE_DISABLE;
  hsram1.Init.AsynchronousWait = FSMC_ASYNCHRONOUS_WAIT_DISABLE;
  hsram1.Init.WriteBurst = FSMC_WRITE_BURST_DISABLE;
  /* Timing */
  Timing.AddressSetupTime = 1;
  Timing.AddressHoldTime = 15;
  Timing.DataSetupTime = 5;
  Timing.BusTurnAroundDuration = 1;
  Timing.CLKDivision = 16;
  Timing.DataLatency = 17;
  Timing.AccessMode = FSMC_ACCESS_MODE_A;
  /* ExtTiming */

  if (HAL_SRAM_Init(&hsram1, &Timing, NULL) != HAL_OK)
  {
    Error_Handler( );
  }

  /* USER CODE BEGIN FSMC_Init 2 */

  /* USER CODE END FSMC_Init 2 */
}

/* USER CODE BEGIN 4 */
 

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
