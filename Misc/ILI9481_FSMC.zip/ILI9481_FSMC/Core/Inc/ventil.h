#ifndef _VENTIL_H_
#define _VENTIL_H_

 #include "main.h"
 #include "stm32f2xx_hal.h"  
 
	void ventil (uint8_t enc);
 
#endif  /* _VENTIL_H_ */
